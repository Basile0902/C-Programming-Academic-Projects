#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#ifdef _WIN32
   #include <windows.h>
#endif

// BASILE FILIPPOS-IOANNIS it2024065

void F5(int minN,int maxN,char chgb[],double minM,double maxM,char *n[],int an[],char *s[],char *cgb[],double am[]);

void PrintPeriodic()  //Function for printing the title
{
  printf(" | -------------------------- |\n");
  printf(" | Periodic Table of Elements |\n");
  printf(" | -------------------------- |\n");
}

void ClearScreen()  //  Function for clearing the terminal
{
    #ifdef _WIN32
      system("cls");
    #else
      system("clear");
    #endif
}

void redText()  //Function for the red texts
{
  #ifdef _WIN32
     HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
     SetConsoleTextAttribute(hConsole,FOREGROUND_RED | FOREGROUND_INTENSITY);
  #else
     printf("\033[1;31m");
  #endif
}

void resetCol()  //Function for reset from red to default text
{
  #ifdef _WIN32
     HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
     SetConsoleTextAttribute(hConsole,7);
  #else
     printf("\033[0m");
  #endif
}

void PrintElement(int i,int minN,int maxN,double minM,double maxM,char chgb[],char *n[],int an[],char *s[],char *cgb[],double am[])  //Function for printing the elements
{
if (minN!=0 && maxN!=0 && minM!=0 && maxM!=0 && strcmp(chgb,"0")!=0)
    {
      if (an[i]>=minN && an[i]<=maxN && strcasecmp(cgb[i],chgb)==0 && am[i]>=minM && am[i]<=maxM)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else{
        printf("%3d:%s",an[i],s[i]);
      }
    }else if (minN==0 && maxN==0 && strcmp(chgb,"0")!=0 && minM!=0 && maxM!=0)
    {
      if (strcasecmp(chgb,cgb[i])==0 && am[i]>=minM && am[i]<=maxM)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else{
        printf("%3d:%s",an[i],s[i]);
      }
    }else if (minM==0 && maxM==0 && minN!=0 && maxN!=0 && strcmp(chgb,"0")!=0)
    {
      if (an[i]>=minN && an[i]<=maxN && strcasecmp(cgb[i],chgb)==0)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else
      {
        printf("%3d:%s",an[i],s[i]);
      }
    }else if (minN!=0 && maxN!=0 && minM!=0 && maxM!=0 && strcmp(chgb,"0")==0)
    {
      if (an[i]>=minN && an[i]<=maxN && am[i]>=minM && am[i]<=maxM)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else{
        printf("%3d:%s",an[i],s[i]);
      }

    }else if (minN==0 && maxN==0 && minM==0 && maxM==0 && strcmp(chgb,"0")!=0)
    {
      if (strcasecmp(chgb,cgb[i])==0)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else{
        printf("%3d:%s",an[i],s[i]);
      }

    }else if (minN==0 && maxN==0 && strcmp(chgb,"0")==0 && minM!=0 && maxM!=0)
    {
      if (am[i]>=minM && am[i]<=maxM)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else{
        printf("%3d:%s",an[i],s[i]);
      }

    }else if (minM==0 && maxM==0 && strcmp(chgb,"0")==0 && minN!=0 && maxN!=0)
    {
      if (an[i]>=minN && an[i]<=maxN)
      {
        redText();
        printf("%3d:%s",an[i],s[i]);
        resetCol();
      }else{
        printf("%3d:%s",an[i],s[i]);
      }

    }
}

void F1()  // First display menu
{
    ClearScreen();
    PrintPeriodic();
    printf("\n");
    printf("\n");
    printf("1.Search for individual elements\n");
    printf("2.Search for group of elements\n");
    printf("3.Terminate application\n");
    printf("\n");
    printf("Type your selection (1,2 or 3): ");
}

void F2()  // Menu for individual element
{
  ClearScreen();
  PrintPeriodic();
  printf("\n");
  printf("Individual element search, based on:\n");
  printf("1. Atomic number\n");
  printf("2. Name\n");
  printf("3. Symbol\n");
  printf("\n");
  printf("\n");
  printf("Type your selection (1,2 or 3): ");
}

void F3(int i,char *n[],int an[],char *s[],char *cgb[],double am[])  //  Function for printing an indivual element's description
{
  ClearScreen();
  PrintPeriodic();
  printf("\n");
  printf("Element Description\n");
  printf("1.Atomic Number: %d\n",an[i]);
  printf("2.Name: %s\n",n[i]);
  printf("3.Symbol: %s\n",s[i]);
  printf("4.Chemical group block: %s\n",cgb[i]);
  printf("5.Atomic Mass: %f\n",am[i]);
}



void F4(char *n[],int an[],char *s[],char *cgb[],double am[])  //  Menu for group of elements
{
  int minN,maxN,temp1,temp2,temp4,temp5,flag=0;
  double minM,maxM;
  char chgb[40],*temp3;

    ClearScreen();
    PrintPeriodic();
    printf("\n");
    printf("Group of elements search, define criteria:\n");
    do{
    printf("1.Minimum atomic number: ");
    temp1=scanf("%d",&minN);
    if (temp1!=1)
        {
           printf("Error!\n");
           exit(1);
        }
    printf("2.Maximum atomic number: ");
    temp2=scanf("%d",&maxN);
    if(temp2!=1)
       {
          printf("Error!\n");
          exit(1);
       }
    if(minN<0 || maxN<0 || minN>maxN)
      {
        printf("Error!\n");
      }
    
    } while(minN<0 || maxN<0 || minN>maxN);
    while(getchar()!='\n');
    {
      do{
       printf("3.Chemical Group Block :");
       fgets(chgb,40,stdin);
       chgb[strcspn(chgb,"\n")]='\0';
      for(int i=0;i<118;i++)
        {
         if(strcasecmp(chgb,cgb[i])==0)
           {
             flag=1;
           }
        }
        if(flag!=1 && strcmp(chgb,"0")!=0)
        {
          printf("Error!\n");
        }
      }while(flag!=1 && strcmp(chgb,"0")!=0);
    }
    do{
      printf("4.Minimum atomic mass: ");
      temp4=scanf("%lf",&minM);
      if(temp4!=1)
         {
            printf("Error!\n");
            exit(1);
         }
      printf("5.Maximum atomic mass: ");
      temp5=scanf("%lf",&maxM);
      if(temp5!=1)
         {
            printf("Error!\n");
            exit(1);
         }
      if(minM<0 || maxM<0 || minM>maxM)
        {
           printf("Error!\n");
        }
    }while(minM<0 || maxM<0 || minM>maxM);
  F5(minN,maxN,chgb,minM,maxM,n,an,s,cgb,am);
}

void F5(int minN,int maxN,char chgb[],double minM,double maxM,char *n[],int an[],char *s[],char *cgb[],double am[])  //Function for group of elements
{
  ClearScreen();
  printf("%50s"," ");
  printf(" | -------------------------- |\n");
  printf("%50s"," ");
  printf(" | Periodic Table of Elements |\n");
  printf("%50s"," ");
  printf(" | -------------------------- |\n");
  printf("\n");
  printf("\n");
  printf("\n");
  printf("Selected group of elements");
  printf("\n");
  printf("\n");
  printf("\n");
 for (int i = 0; i < 118; i++)
 {

  if (i==0)

  {
    PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
  }
  if (i==1)
  {
    printf("%113s"," ");
    PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
    printf("\n");
  }
  if (i>=2 && i<=9)
  {
      PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
      if (i==3)
      {
        printf("%70s"," ");
      }else{
        printf(" ");
      }
      if(i>=4)
      {
         printf(" ");
      }
      if (i==9)
      {
        printf("\n");
      }

  }
  if (i>=10 && i<=17)
  {

      PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
      if (i==11)
      {
         printf("%70s"," ");
      }else{
        printf(" ");
      }
      if(i==14 || i==15)
      {
         printf(" ");
      }
      if (i==17)
      {
        printf("\n");
      }

  }
   if(i>=18 && i<=35)
   {
    PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
    printf(" ");
    if(i==22)
    {
      printf(" ");
    }
    if(i==35)
    {
      printf("\n");
    }
   }
  if(i>=36 && i<=53)
  {
    PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
    printf(" ");
    if (i==52)
    {
      printf(" ");
    }
    if (i==53)
    {
      printf("\n");
    }
  }
   if(i==54){
    PrintElement(54,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
    printf(" ");
    PrintElement(55,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
    printf("       ");
   }
   if(i>=56 && i<=70)
   {
     PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
     printf(" ");
     if(i==58)
     {
       printf(" ");
     }
     if(i==70)
     {
       printf("\n");
     }
   }
   if (i==71)
   {
     PrintElement(71,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
     printf(" ");
     PrintElement(72,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
     printf("       ");
   }
   if(i>=73 && i<=87)
   {
     PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
     printf(" ");
     if(i==87)
     {
       printf("\n");
     }
   }
   if(i>=88 && i<=102)
   {
     if (i==88)
     {
     printf("%20s"," ");
     }
     PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
     printf(" ");
     if(i==102)
     {
        printf("\n");
     }
   }
  if(i>=103 && i<=117)
  {
    if(i==103)
    {
       printf("%20s"," ");
    }
    PrintElement(i,minN,maxN,minM,maxM,chgb,n,an,s,cgb,am);
    printf(" ");
    if(i==106)
    {
      printf(" ");
    }
  }
 }

}


int main()
{
    int selection,temp;
    //Names
    char *Names[]={"Hydrogen","Helium","Lithium","Beryllium","Boron","Carbon","Nitrogen","Oxygen","Fluorine","Neon","Sodium","Magnesium","Aluminium","Silicon","Phosphorus","Sulfur","Chlorine","Argon","Potassium","Calcium","Scandium","Titanium","Vanadium","Chromium","Manganese","Iron","Cobalt","Nickel","Copper","Zinc","Gallium","Germanium","Arsenic","Selenemium","Bromine","Krypton","Rubidium","Strontium","Yttrium","Zirconium","Niobium","Molybdenum","Technetium","Ruthenium","Rhodium","Palladium","Silver","Cadmium","Indium","Tin","Antimony","Tellurium","Iodine","Xenon","Cesium","Barium","Hafnium","Tantalum","Tungsten","Rhenium","Osmium","Iridium","Platinum","Gold","Mercury","Thallium","Lead","Bismuth","Polonium","Astatine","Radon","Francium","Radium","Rutherfordium","Dubnium","Seaborgium","Bohrium","Hassium","Meitnerium","Darmstaftium","Roentgenium","Copernicium","Nihonium","Flerovium","Moscovium","Livermorium","Tennessine","Oganesson","Lathanum","Cerium","Praseodymium","Neodymium","Promethium","Samarium","Europium","Gadolinium","Terbium","Dysprosium","Holmium","Erbium","Thulium","Ytterbium","Lutemium","Actinium","Thorium","Protactinium","Uranium","Neptunium","Plutonium","Americium","Curium","Berkelium","Californium","Einsteinium","Fermium","Mendelevium","Nobelium","Lawrencium"};
    //Atomic Numbers
    int aNum[]={1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,104,105,106,107,108,109,110,111,112,113,114,115,116,117,118,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103};
    // Symbols
    char *Sy[]={"H","He","Li","Be","B","C","N","O","F","Ne","Na","Mg","Al","Si","P","S","Cl","Ar","K","Ca","Sc","Ti","V","Cr","Mn","Fe","Co","Ni","Cu","Zn","Ga","Ge","As","Se","Br","Kr","Rb","Sr","Y","Zr","Nb","Mo","Tc","Ru","Rh","Pd","Ag","Cd","In","Sn","Sb","Te","I","Xe","Cs","Ba","Hf","Ta","W","Re","Os","Ir","Pt","Au","Hg","Tl","Pb","Bi","Po","At","Rn","Fr","Ra","Rf","Db","Sg","Bh","Hs","Mt","Ds","Rg","Cn","Nh","Fl","Mc","Lv","Ts","Og","La","Ce","Pr","Nd","Pm","Sm","Eu","Gd","Tb","Dy","Ho","Er","Tm","Yb","Lu","Ac","Th","Pa","U","Np","Pu","Am","Cm","Bk","Cf","Es","Fm","Md","No","Lr"};
    // Chemical Group Blocks
    char *CGB[]={"Nonmetal","Noble Gas","Alkali Metal","Alkaline Earth Metal","Metallaid","Nonmetal","Nonmetal","Nonmetal","Halogen","Noble Gas","Alkali Metal","Alkaline Earth Metal","Post-Transition Metal","Metalloid","Nonmetal","Nonmetal","Halogen","Noble Gas","Alkali Metal","Alkaline Earth Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Post-Transition Metal","Metalloid","Metalloid","Nonmetal","Hallogen","Noble Gas","Alkali Metal","Alkaline Earth Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Post-Transition Metal","Post-Transition Metal","Metalloid","Metalloid","Halogen","Noble Gas","Alkali Metal","Alkaline Earth Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Post-Transition Metal","Post-Transition Metal","Post-Transition Metal","Metalloid","Halogen","Noble Gas","Alkali Metal","Alkaline Earth Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Transition Metal","Post-Transition Metal","Post-Transition Metal","Post-Transition Metal","Post-Transition Metal","Halogen","Noble Gas","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Lanthadine","Actinide","Actinide","Actinide","Actinide","Actidine","Actidine","Actidine","Actidine","Actidine","Actidine","Actidine","Actidine","Actidine","Actidine","Actidine"};
    // Atomic Masses
    double AM[]={1.0080,4.00260,7.0,9.012183,10.81,12.011,14.007,15.999,18.99840316,20.180,22.9897,24.305,26.981538,28.085,30.9737,32.07,35.45,39.9,39.0983,40.08,44.95591,47.867,50.9415,51.996,54.93804,55.84,58.93319,58.693,63.55,65.4,69.723,72.63,74.92159,78.97,79.90,83.80,85.468,87.62,88.90584,91.22,92.90637,95.95,96.90636,101.1,102.9055,106.42,107.868,112.41,114.818,118.71,121.760,127.6,126.9045,131.29,132.905,137.33,178.49,180.9479,183.84,186.207,190.2,192.22,195.08,196.96657,200.59,204.383,207.0,208.98040,208.98243,209.98715,222.01758,223.01973,226.02541,267.122,268.126,269.128,270.133,269.1336,277.154,282.166,282.169,286.179,286.182,290.192,290.196,293.205,294.211,295.216,138.9055,140.116,140.90766,144.24,144.91276,150.4,151.964,157.25,158.92535,162.500,164.93033,167.26,168.93422,173.05,174.9667,227.02775,232.038,231.03588,238.0289,237.048,244.06420,243.061,247.07035,247.07031,251.07959,252.0830,257.09,258.09,259.10,266.120};
    do
    {

      F1();
      temp=scanf("%d",&selection);
      if(temp!=1)
      {
         printf("Error!\n");
         exit(1);
      }
      if (selection==1)  //  Search for individual element
      {
        int sel2,temp;
        F2();
        temp=scanf("%d",&sel2);
        if (temp!=1 || sel2<1 || sel2>3)
        {
          do
          {
            F2();
            temp=scanf("%d",&sel2);
          } while (temp!=1 || (sel2<1 || sel2>3));

        }
          printf("\n");
          printf("\n");

          int AtNum,n=0;
          char Name[30],Sym[10];
         do
         {
          if (sel2==1)
          {
            printf("Provide element atomic number: ");
            temp=scanf("%d",&AtNum);
            for (int i = 0; i < 118; i++)
            {

              if (AtNum==aNum[i])
              {
                F3(i,Names,aNum,Sy,CGB,AM);
                n=1;
              }
            }
          }else if (sel2==2)
          {
            printf("Provide element name: ");
            temp=scanf("%s",Name);
            for (int i = 0; i < 118; i++)
            {
              if (strcasecmp(Name,Names[i])==0)
              {
                F3(i,Names,aNum,Sy,CGB,AM);
                n=1;
              }
            } 
          }else{   // Search for group of elements

            printf("Provide element symbol: ");

            scanf("%s",Sym);
            for (int i = 0; i < 118; i++)
            {
                
              if (strcasecmp(Sym,Sy[i])==0)
              {
                F3(i,Names,aNum,Sy,CGB,AM);
                n=1; 
              }
            }
          }
        if (n==0 || temp!=1)
        {
          printf("Error, wrong atomic number or name or symbol!\n");
        }
        
         }while(temp!=1 || n==0);
       
      }else if (selection==2)
      {
        F4(Names,aNum,Sy,CGB,AM);
      }
     printf("\n");
     printf("\n");
     if(selection!=3)
     {
       printf("Do you want to continue (Yes=any number or No=3): ");
       int temp=scanf("%d",&selection);
     }
    } while (selection!=3);
  return 0;  
}
